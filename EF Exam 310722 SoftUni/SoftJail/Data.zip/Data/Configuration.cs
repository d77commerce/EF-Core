﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=D77COMMERCE\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
